[GROUP 8]

HOW TO RUN 

  if necessary, cd to "mydb_project" and update the permissions for run.sh to executable --> chmod 744 run.sh
  
  use run.sh file to run the Driver.java file --> ./run.sh 


CONTRIBUTIONS
 
  Casey (crw80000@uga.edu): Union and Difference methods, 4 example queries
  
  Diya (da71571@uga.edu): Select and Rename methods, 1 example query
  
  Steven (spp60436@uga.edu): Both Join methods
  
  Rayna(rmb11589@uga.edu): Cartesian Product and Project methods
